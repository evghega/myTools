The author's contact information:
Evghenii Gaisinschii 336551072

Title of the project:
Write a programm that get a photo of a rectangular page and aligns the photo.

Installation instruction:
Need to install following libraries: 
	import cv2
	import numpy as np
	import sys
	import os

How to Run Your Program:
Like was said in work requirements, the programm needs to be executed in command line. 
Need to write python code file, input directory with file name to execute and 
output directory, where we need to save our image.