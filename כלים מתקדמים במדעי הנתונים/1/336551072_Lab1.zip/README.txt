Libraries to import:

	import nest_asyncio
	nest_asyncio.apply()
	import twint
	import pandas as pd
	import tweepy 
	from pymongo import MongoClient
	import pandas as pd
	import numpy as np
	import tweepy 
	from pymongo import MongoClient
	from tkinter import *



Execution instructions:

	- Run MongoDB Server
	- Run Lab1.py file in command line (no parameters needed). 
		- or run Lab1.py with Jupyter Notebook 